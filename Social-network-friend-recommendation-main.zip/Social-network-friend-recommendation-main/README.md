# Social-network-friend-recommendation
A graph-based Social Network Friend Recommendation System that recommends potential friends using mutual connections and graph algorithms such as BFS, Min-Heap, Union-Find, and Trie. Built with C++, TypeScript, React, and Supabase.
